package IkaMapEditor;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.Vector;

import javax.swing.Action;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JRadioButton;

public class ScreenSetup extends JFrame implements ActionListener {
	ButtonGroup group = new ButtonGroup();
//	private static JRadioButton sizeRB_10180 = new JRadioButton("101*80");
//	private static JRadioButton sizeRB_176204 = new JRadioButton("176*204");
//	private static JRadioButton sizeRB_176208 = new JRadioButton("176*208");
//	private static JRadioButton sizeRB_176220 = new JRadioButton("176*220");
//	private static JRadioButton sizeRB_128116 = new JRadioButton("128*116");
//	private static JRadioButton sizeRB_128128 = new JRadioButton("128*128");
//	private static JRadioButton sizeRB_128160 = new JRadioButton("128*160");
//	private static JRadioButton sizeRB_208208 = new JRadioButton("208*208");
//	private static JRadioButton sizeRB_208320 = new JRadioButton("208*320");
//	private static JRadioButton sizeRB_240320 = new JRadioButton("240*320");
	private static final long serialVersionUID = 1L;
	private static JButton Botton_OK = new JButton("ȷ��");
    private Vector<JRadioButton> buttonlist=new Vector<JRadioButton>();
	public static int[][] size_matrix={{128,160},{176,208},{240,320},{320,240},{360,640},{640,360},{320,480},{480,320},{480,854},{854,480}};
	
	
	
	public ScreenSetup(int x, int y) {

		this.setTitle("Ԥ����������");
		this.setSize(70, 25*size_matrix.length);
		this.setAlwaysOnTop(true);
		this.setLocation(x, y);
		this.setResizable(false); // ���岻�ܸı��С
		this.setLayout(new GridLayout(11, 1));
		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				this.windowClosed(e);
			}
		});

		buttonlist.removeAllElements();
		for(int i=0;i<size_matrix.length;i++){
		    JRadioButton sizeRB = new JRadioButton(size_matrix[i][0]+"*"+size_matrix[i][1]);
		    group.add(sizeRB);
		    if(i==0){
		        sizeRB.setSelected(true);
		    }else{
		        sizeRB.setSelected(false);
		    }
		    this.add(sizeRB);
		    sizeRB.addActionListener(this);
		    buttonlist.add(sizeRB);
		}
		this.add(Botton_OK);
		Botton_OK.addActionListener(this);
		setVisible(true);
	}

	public void actionPerformed(ActionEvent e) {
		Object source = e.getSource();
		if (source == Botton_OK) {
		    for(int i=0;i<buttonlist.size();i++){
		        JRadioButton jrb= buttonlist.elementAt(i);
		      if(jrb.isSelected()){
		            SDef.srceensize=size_matrix[i];
		        }
		      jrb.setSelected(false);
		      jrb.removeActionListener(this);
		    }
		    System.out.println(buttonlist.size()+":"+  SDef.srceensize[0]+","+  SDef.srceensize[1]);
		    Botton_OK.removeActionListener(this);
		    setVisible(false);
		}
	}
}
