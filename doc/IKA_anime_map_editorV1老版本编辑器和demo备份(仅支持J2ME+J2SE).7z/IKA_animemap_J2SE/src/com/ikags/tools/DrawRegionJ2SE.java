package com.ikags.tools;

import java.awt.Graphics;
import java.awt.geom.AffineTransform;
import java.awt.image.AffineTransformOp;
import java.awt.image.BufferedImage;

public class DrawRegionJ2SE
{
    // �滭����
    public static void drawAniPart20(BufferedImage[] mod_bfimage,int n, int x, int y, int trans, Graphics g)
    {

        if (mod_bfimage[n] == null)
        {
            return;
        }

        if (trans == 0)
        {
            rotate90(mod_bfimage[n], 0, n);
            g.drawImage(filteredImage, x, y, null);
        }
        else
        {
            switch (trans)
            {
                case 1: // X����
                    rotate90(mod_bfimage[n], 0, n);
                    // g.drawImage(filteredImage, x - filteredImage.getWidth(), y, x, y + filteredImage.getHeight(), filteredImage.getWidth(), 0,
                    // 0,filteredImage.getHeight(), null); // X����
                    g.drawImage(filteredImage, x, y, x + filteredImage.getWidth(), y + filteredImage.getHeight(), filteredImage.getWidth(), 0, 0, filteredImage.getHeight(), null); // X����

                    break;
                case 2: // Y����
                    rotate90(mod_bfimage[n], 0, n);
                    g.drawImage(filteredImage, x, y, x + filteredImage.getWidth(), y + filteredImage.getHeight(), 0, filteredImage.getHeight(), filteredImage.getWidth(), 0, null); // Y����
                    break;
                case 3: // X����+Y���� ������ת180��
                    rotate90(mod_bfimage[n], 180, n);
                    g.drawImage(filteredImage, x, y, null);
                    break;
                case 4: // ��ת270+Y����
                    rotate90(mod_bfimage[n], 270, n);
                    g.drawImage(filteredImage, x, y, x + filteredImage.getWidth(), y + filteredImage.getHeight(), filteredImage.getWidth(), 0, 0, filteredImage.getHeight(), null); // Y����
                    break;
                case 5: // ��ת90
                    rotate90(mod_bfimage[n], 90, n);
                    g.drawImage(filteredImage, x, y, null);
                    break;
                case 6: // ��ת270
                    rotate90(mod_bfimage[n], 270, n);
                    g.drawImage(filteredImage, x, y, null);
                    break;
                case 7: // ��ת90+Y����
                    rotate90(mod_bfimage[n], 90, n);
                    g.drawImage(filteredImage, x, y, x + filteredImage.getWidth(), y + filteredImage.getHeight(), filteredImage.getWidth(), 0, 0, filteredImage.getHeight(), null); // Y����
                    break;
                default:
                    System.out.println("2.0trans error");
                    break;
            }
        }
    }

    
    // �滭����
    private static void drawAniPart20(BufferedImage mod_bfimage, int x, int y, int trans, Graphics g)
    {

        if (mod_bfimage == null)
        {
            return;
        }

        if (trans == 0)
        {
            rotate90(mod_bfimage, 0, 0);
            g.drawImage(filteredImage, x, y, null);
        }
        else
        {
            switch (trans)
            {
                case 1: // X����
                    rotate90(mod_bfimage, 0, 0);
                    // g.drawImage(filteredImage, x - filteredImage.getWidth(), y, x, y + filteredImage.getHeight(), filteredImage.getWidth(), 0,
                    // 0,filteredImage.getHeight(), null); // X����
                    g.drawImage(filteredImage, x, y, x + filteredImage.getWidth(), y + filteredImage.getHeight(), filteredImage.getWidth(), 0, 0, filteredImage.getHeight(), null); // X����

                    break;
                case 2: // Y����
                    rotate90(mod_bfimage, 0, 0);
                    g.drawImage(filteredImage, x, y, x + filteredImage.getWidth(), y + filteredImage.getHeight(), 0, filteredImage.getHeight(), filteredImage.getWidth(), 0, null); // Y����
                    break;
                case 3: // X����+Y���� ������ת180��
                    rotate90(mod_bfimage, 180, 0);
                    g.drawImage(filteredImage, x, y, null);
                    break;
                case 4: // ��ת270+Y����
                    rotate90(mod_bfimage, 270, 0);
                    g.drawImage(filteredImage, x, y, x + filteredImage.getWidth(), y + filteredImage.getHeight(), filteredImage.getWidth(), 0, 0, filteredImage.getHeight(), null); // Y����
                    break;
                case 5: // ��ת90
                    rotate90(mod_bfimage, 90, 0);
                    g.drawImage(filteredImage, x, y, null);
                    break;
                case 6: // ��ת270
                    rotate90(mod_bfimage, 270, 0);
                    g.drawImage(filteredImage, x, y, null);
                    break;
                case 7: // ��ת90+Y����
                    rotate90(mod_bfimage, 90, 0);
                    g.drawImage(filteredImage, x, y, x + filteredImage.getWidth(), y + filteredImage.getHeight(), filteredImage.getWidth(), 0, 0, filteredImage.getHeight(), null); // Y����
                    break;
                default:
                    System.out.println("2.0trans error");
                    break;
            }
        }
    }
    
    
    
    public static void drawRegionJ2SE(BufferedImage mod_bfimage, int x, int y, int trans,int acher, Graphics g){
        switch(acher){
            case 0:
            case 20://����
                drawAniPart20( mod_bfimage,x,y,trans,g);
                break;
            case 24://����
                drawAniPart20( mod_bfimage,x-mod_bfimage.getWidth(),y,trans,g);
                break;
            case 36://����
                drawAniPart20( mod_bfimage,x,y-mod_bfimage.getHeight(),trans,g);
                break;
            case 40://����
                drawAniPart20( mod_bfimage,x-mod_bfimage.getWidth(),y-mod_bfimage.getHeight(),trans,g);
                break;
            
        }
        
      
    }
    
    // ��ת
    public static AffineTransform transform;
    public static AffineTransformOp op;
    public static BufferedImage filteredImage;

    public static void rotate90(BufferedImage img, int angle, int n)
    {
        switch (angle)
        {
            case 0:
                transform = AffineTransform.getRotateInstance(Math.toRadians(0), 0, 0);
                op = new AffineTransformOp(transform, AffineTransformOp.TYPE_BILINEAR);
                filteredImage = new BufferedImage(img.getWidth(), img.getHeight(), img.getType());
                op.filter(img, filteredImage);
                break;
            case 90:
                transform = AffineTransform.getRotateInstance(Math.toRadians(90), img.getHeight() / 2, img.getHeight() / 2);
                op = new AffineTransformOp(transform, AffineTransformOp.TYPE_BILINEAR);
                filteredImage = new BufferedImage(img.getHeight(), img.getWidth(), img.getType());
                op.filter(img, filteredImage);
                // img = filteredImage;
                break;
            case 180:
                transform = AffineTransform.getRotateInstance(Math.toRadians(180), img.getWidth() / 2, img.getHeight() / 2);
                op = new AffineTransformOp(transform, AffineTransformOp.TYPE_BILINEAR);
                filteredImage = new BufferedImage(img.getWidth(), img.getHeight(), img.getType());
                op.filter(img, filteredImage);
                // img = filteredImage;
                break;
            case 270:
                transform = AffineTransform.getRotateInstance(Math.toRadians(270), img.getWidth() / 2, img.getWidth() / 2);
                op = new AffineTransformOp(transform, AffineTransformOp.TYPE_BILINEAR);
                filteredImage = new BufferedImage(img.getHeight(), img.getWidth(), img.getType());
                op.filter(img, filteredImage);
                // img = filteredImage;
                break;

        }
    }
}
