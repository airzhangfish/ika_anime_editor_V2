

import java.applet.Applet;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.geom.AffineTransform;
import java.awt.image.AffineTransformOp;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.event.MouseInputAdapter;

import animetest_application.anime.AnimeEngine;
import animetest_application.anime.AnimeSprite;
import animetest_application.anime.GSprite;

public class AnimeApplet extends Applet implements Runnable
{

    private static final long serialVersionUID = 1L;
    Thread th;
    BufferedImage bfimg;

    static AnimeApplet map = null;

    static GSprite gsprite=null;
    
    public void init(){
        map = new AnimeApplet(); 
    }
    
    
    
    public void start()
    {
        String path = System.getProperty("user.dir");
        System.out.println("path:" + path);
         AnimeEngine.getInstance().imgSprite_pool[0]=new AnimeSprite(path+"//anime_simple.ika",path+"//anime_imgpak.bin");
         gsprite=new GSprite(200,200,0,0,true);
        
    }

   

    public AnimeApplet()
    {

//        this.setTitle("IKA��ͼԤ����");
//        this.setSize(640, 480);
//        this.setAlwaysOnTop(true);
//        this.setResizable(true); // ���岻�ܸı��С
        runing = true;

        MyListener myListener = new MyListener();
        addMouseListener(myListener);
        addMouseMotionListener(myListener);
        MAmouseX = getX() + 10;
        MAmouseY = getY() + 10;
        this.setSize(320, 240);
        bfimg = new BufferedImage(this.getWidth(), this.getHeight(), BufferedImage.TYPE_INT_ARGB);
        setVisible(true);
        th = new Thread(this);
//        addWindowListener(new WindowAdapter()
//        {
//            public void windowClosing(WindowEvent e)
//            {
//                runing = false;
//                th = null;
//                this.windowClosed(e);
//            }
//        });
        th.start();
    }

    int MAmouseX = 0;
    int MAmouseY = 0;

    class MyListener extends MouseInputAdapter
    {
        public void mouseMoved(MouseEvent e)
        {
            MAmouseX = e.getX();
            MAmouseY = e.getY();
        }
    }

    int map_moveX = 100;
    int map_moveY = 100;
    public static Color Color_HEI = new Color(0, 0, 0);
    public static Color Color_BAI = new Color(255, 255, 255);
    public void paint(Graphics g)
    {
//        Graphics gg = bfimg.getGraphics();
//        Graphics2D g2 = ( Graphics2D ) gg;
//        g2.setColor(Color_HEI);
//        g2.setClip(0, 0, getWidth(), getHeight());
//        g2.clipRect(0, 0, getWidth(), getHeight());
//        g2.fillRect(0, 0, getWidth(), getHeight());
//
//        //TODO  ͼ��ʼ����
//        if(gsprite!=null){
//            try{
//            gsprite.paint(g2);
//            }catch(Exception ex){
//                ex.printStackTrace();
//            }
//        }
//
//        g2.setColor(Color_BAI);
//        g2.drawString("����:" + map_moveX + "," + map_moveY + ":", 50, 50);
//        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
//        g.drawImage(bfimg, 0, 0, null);
//        

        
        
        try{
            g=this.getGraphics();
       if(g==null){
           return;
       }
            Graphics gg = bfimg.getGraphics();
            gg.setColor(Color_HEI);
            gg.setClip(0, 0, getWidth(), getHeight());
            gg.clipRect(0, 0, getWidth(), getHeight());
            gg.fillRect(0, 0, getWidth(), getHeight());

            //TODO  ͼ��ʼ����
            if(gsprite!=null){
                try{
                gsprite.paint(gg);
                }catch(Exception ex){
                    ex.printStackTrace();
                }
            }

          gg.setColor(Color_BAI);
          gg.drawString("����:" + map_moveX + "," + map_moveY + ":", 50, 50);
          
          g.drawImage(bfimg, 0,0,null);
          
            }catch(Exception ex){
                ex.printStackTrace();
            }
    }

    public boolean runing = true;
    public int box_X = 0;
    public int box_Y = 0;
    public int box_W = 0;
    public int box_H = 0;

    public void mousemovemap()
    {
        box_X = this.getWidth() / 4;
        box_Y = this.getHeight() / 4;
        box_W = this.getWidth() / 2;
        box_H = this.getHeight() / 2;
        int mouseX = MAmouseX;
        int mouseY = MAmouseY;
        // System.out.println("mouse:"+mouseX+","+mouseY);
        // System.out.println("getbox:"+this.getX()+","+this.getY()+","+this.getWidth()+","+this.getHeight());
        // if(mouseX>box_X && mouseX<box_X+box_W &&mouseY>box_Y&&mouseY<box_Y+box_H){
        // //ֹͣ
        // SCR_state=SCR_stop;
        // }else
        if (mouseX > box_X && mouseX < box_X + box_W && mouseY < box_Y)
        {
            // ����
            SCR_state = SCR_up;
        }
        else if (mouseX > box_X && mouseX < box_X + box_W && mouseY > box_Y + box_H)
        {
            // ����
            SCR_state = SCR_down;
        }
        else if (mouseX < box_X && mouseY > box_Y && mouseY < box_Y + box_H)
        {
            // ���
            SCR_state = SCR_left;
        }
        else if (mouseX > box_X + box_W && mouseY > box_Y && mouseY < box_Y + box_H)
        {
            // �ұ�
            SCR_state = SCR_right;
        }
        else
        {
            SCR_state = SCR_stop;
        }
    }

    public byte SCR_state = 0;
    public final byte SCR_stop = 0;
    public final byte SCR_up = 1;
    public final byte SCR_down = 2;
    public final byte SCR_left = 3;
    public final byte SCR_right = 4;

    public void run()
    {
        while (runing)
        {
            mousemovemap();
            repaint();

            try
            {
                Thread.sleep(60);
            }
            catch (Exception ex)
            {
            }
        }
    }

   
   
}
