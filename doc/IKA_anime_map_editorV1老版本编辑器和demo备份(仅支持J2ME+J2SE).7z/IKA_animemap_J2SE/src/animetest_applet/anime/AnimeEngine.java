package animetest_applet.anime;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;

import javax.imageio.ImageIO;

import com.ikags.tools.DrawRegionJ2SE;


/**
 * I.K.A Engine<BR>
 * AnimeEngine�࣬���������࣬�Ͷ���������<BR>
 * ʹ�÷���:<BR>
 * ��������:<BR>
 * AnimeEngine.imgSprite_pool[0]=new AnimeSprite("/logo.ika","/logo.bin");<BR>
 * GSprite gsprite=new GSprite(104,136,0,0,true);<BR>
 * ʹ�÷���:<BR>
 * gsprite.paint(g);<BR>
 * �����ڴ淽��:<BR>
 * gsprite=null;<BR>
 * AnimeEngine.imgSprite_pool[0].setNull();<BR>
 * AnimeEngine.imgSprite_pool[0]=null;<BR>
 * System.gc();<BR>
 * @author http://airzhangfish.spaces.live.com
 * @since 2005.11.15 ������ 2009.5.20
 * @version 0.6
 */
public class AnimeEngine
{

    private static AnimeEngine ae = null;

    public static AnimeEngine getInstance()
    {
        if (ae == null)
        {
            ae = new AnimeEngine();
        }
        return ae;
    }

    /**
     * ������,���ڴ��涯��,Ĭ��9��ռ�
     */
    public AnimeSprite[] imgSprite_pool = new AnimeSprite[9];

    /**
     * ��ʼ��
     */
    public AnimeEngine()
    {
    }

    /**
     * ����ͼƬ��ȡ
     * @param path ͼƬbin�ļ�·��
     * @param img_sprite ����������
     */
    public void load_Image(String path, AnimeSprite img_sprite)
    { // ����ͼƬ��ȡ
        // ��ȡͼƬ
        File datamap = new File(path);
        try
        {
            FileInputStream is = new FileInputStream(datamap);
            img_sprite.anime_Piece = (is.read() << 8) + is.read();
            System.out.println("total PNG:" + img_sprite.anime_Piece);
            img_sprite.AnimeImg = new BufferedImage[img_sprite.anime_Piece];
            for (int i = 0; i < img_sprite.anime_Piece; i++)
            {
                byte[] image_matrix;
                int image_length = (is.read() << 8) + is.read();
                image_matrix = new byte[image_length];
                is.read(image_matrix, 0, image_length);
                
                //����ͼƬ
                File tmpfile = new File(System.currentTimeMillis() + ".png");
                FileOutputStream fo = new FileOutputStream(tmpfile);
                fo.write(image_matrix);
                fo.close();
                img_sprite.AnimeImg[i] = ImageIO.read(tmpfile);
                ImageIO.write(img_sprite.AnimeImg[i], "png", tmpfile);
                tmpfile.delete();
                //TODO createImage
//                img_sprite.AnimeImg[i] = Image.createImage(image_matrix, 0, image_length);
            }
        }
        catch (Exception e)
        {
            System.out.println("images read error");
        }
    }

    /**
     * ���������ļ���ȡ
     * @param path ͼƬbin�ļ�·��
     * @param img_sprite ����������
     */
    public void load_Anime(String path, AnimeSprite img_sprite)
    {
        short[] inputintdata;
        try
        {
            File datamap = new File(path);
            FileInputStream fo = new FileInputStream(datamap);
            inputintdata = new short[fo.available() / 2];
            for (int i = 0; i < inputintdata.length; i++)
            {
                inputintdata[i] = ( short ) ((fo.read() << 8) + fo.read());
            }
            fo.close();
            int modlength = 0;
            int readID = 0;
            modlength = inputintdata[readID];
            readID++;
            img_sprite.G_modbox = new short[modlength][6];
            for (int i = 0; i < modlength; i++)
            {
                for (int j = 0; j < 6; j++)
                {
                    img_sprite.G_modbox[i][j] = inputintdata[readID];
                    readID++;
                }
            }
            int framelength = 0;
            framelength = inputintdata[readID];
            readID++;
            img_sprite.G_framebox = new short[framelength][];
            for (int i = 0; i < framelength; i++)
            {
                int temp_length = inputintdata[readID + 1];
                img_sprite.G_framebox[i] = new short[temp_length * 4 + 2];
                for (int j = 0; j < temp_length * 4 + 2; j++)
                {
                    img_sprite.G_framebox[i][j] = inputintdata[readID];
                    readID++;
                }
            }
            int animelength = 0;
            animelength = inputintdata[readID];
            readID++;
            img_sprite.G_animebox = new short[animelength][];
            for (int i = 0; i < animelength; i++)
            {
                int temp_length = inputintdata[readID + 1];
                img_sprite.G_animebox[i] = new short[temp_length + 2];
                for (int j = 0; j < temp_length + 2; j++)
                {
                    img_sprite.G_animebox[i][j] = inputintdata[readID];
                    readID++;
                }
            }
            for (int i = 0; i < animelength; i++)
            {
                System.out.println("");
                for (int j = 0; j < img_sprite.G_animebox[i].length; j++)
                {
                    System.out.print(img_sprite.G_animebox[i][j] + ",");
                }
            }
            System.out.println("read ika over");
        }
        catch (Exception ex)
        {
            System.out.println("read ika error");
        }
        inputintdata = null;
    }

    /**
     * ��ʵ�滭��֡
     */
    private int frame_select;
    /**
     * ��������ID
     */
    public int ActSecletNumber = 0;
    /**
     * ��ǰ֡
     */
    public int act_frame = 0;
    /**
     * ��������
     */
    public boolean isleft = true;

    /**
     * �滭����
     * @param g
     * @param x ����
     * @param y ����
     * @param img_sprite ����������
     */
    public void paint(Graphics g, int x, int y, AnimeSprite img_sprite)
    {
        if (ActSecletNumber >= 0)
        {
            frame_select = act_frame % (img_sprite.G_animebox[ActSecletNumber].length - 2);
            for (int i = 0; i < img_sprite.G_framebox[img_sprite.G_animebox[ActSecletNumber][2 + frame_select]][1]; i++)
            {
                int j = i << 2;
                drawAni(img_sprite.AnimeImg[img_sprite.G_framebox[img_sprite.G_animebox[ActSecletNumber][2 + frame_select]][2 + j]], x, img_sprite.G_framebox[img_sprite.G_animebox[ActSecletNumber][2 + frame_select]][2 + j + 1], y,
                    img_sprite.G_framebox[img_sprite.G_animebox[ActSecletNumber][2 + frame_select]][2 + j + 2], img_sprite.G_framebox[img_sprite.G_animebox[ActSecletNumber][2 + frame_select]][2 + j + 3], isleft, g);
            }
            act_frame++;
        }
    }

  
    /**
     * �����õ���淽�� MIDP2.0ʹ��.(nokia api�汾��ͨ����,��ʱ����)
     */
    private void drawAni(BufferedImage img, int x, int bx, int y, int by, int trans, boolean isleft, Graphics g)
    {
        if (isleft == true)
        {
            if (trans == 0)
            {
//                g.drawImage(img, x + bx, y + by, 20);
                  DrawRegionJ2SE.drawRegionJ2SE(img, x + bx, y + by, trans, 20, g) ;
            }
            else
            {
                switch (trans)
                {
                    case 1: // X����
//                        g.drawRegion(img, 0, 0, img.getWidth(), img.getHeight(), 2, x + bx, y + by, 24);
                        DrawRegionJ2SE.drawRegionJ2SE(img, x + bx, y + by, trans, 24, g) ;
                        break;
                    case 2: // Y����
//                        g.drawRegion(img, 0, 0, img.getWidth(), img.getHeight(), 1, x + bx, y + by, 36);
                        DrawRegionJ2SE.drawRegionJ2SE(img, x + bx, y + by, trans, 36, g) ;
                        break;
                    case 3: // X����+Y����
//                        g.drawRegion(img, 0, 0, img.getWidth(), img.getHeight(), 3, x + bx, y + by, 40);
                        DrawRegionJ2SE.drawRegionJ2SE(img, x + bx, y + by, trans, 40, g) ;
                        break;
                    case 4: // ��ת90+Y����
//                        g.drawRegion(img, 0, 0, img.getWidth(), img.getHeight(), 7, x + bx + img.getHeight(), y + by + img.getWidth(), 40);
                        DrawRegionJ2SE.drawRegionJ2SE(img, x + bx + img.getHeight(), y + by + img.getWidth(), trans, 40, g) ;
                        break;
                    case 5: // ��ת90
//                        g.drawRegion(img, 0, 0, img.getWidth(), img.getHeight(), 5, x + bx + img.getHeight(), y + by, 24);
                        DrawRegionJ2SE.drawRegionJ2SE(img,x + bx + img.getHeight(), y + by, trans, 24, g) ;
                        
                        break;
                    case 6: // ��ת270
//                        g.drawRegion(img, 0, 0, img.getWidth(), img.getHeight(), 6, x + bx, y + by + img.getWidth(), 36);
                        DrawRegionJ2SE.drawRegionJ2SE(img, x + bx, y + by + img.getWidth(), trans, 36, g) ;
                        
                        break;
                    case 7: // ��ת270+Y����
//                        g.drawRegion(img, 0, 0, img.getWidth(), img.getHeight(), 4, x + bx, y + by, 20);
                        DrawRegionJ2SE.drawRegionJ2SE(img,x + bx, y + by, trans, 20, g) ;
                        
                        break;
                    default:
                        System.out.println("2.0trans error");
                        break;
                }
            }
        }
        else
        {
            if (trans == 0)
            {
//                g.drawRegion(img, 0, 0, img.getWidth(), img.getHeight(), 2, x - bx, y + by, 24);
                DrawRegionJ2SE.drawRegionJ2SE(img,  x - bx, y + by, trans, 24, g) ;
            }
            else
            {
                switch (trans)
                {
                    case 1: // X����
//                        g.drawImage(img, x + bx, y + by, 20);
                        DrawRegionJ2SE.drawRegionJ2SE(img, x + bx, y + by, trans, 20, g) ;
                        break;
                    case 2: // Y����
//                        g.drawRegion(img, 0, 0, img.getWidth(), img.getHeight(), 1, x - bx, y + by, 36);
                        DrawRegionJ2SE.drawRegionJ2SE(img,  x - bx, y + by, trans, 36, g) ;
                        break;
                    case 3: // X����+Y����
//                        g.drawRegion(img, 0, 0, img.getWidth(), img.getHeight(), 3, x - bx, y + by, 40);
                        DrawRegionJ2SE.drawRegionJ2SE(img, x - bx, y + by, trans, 40, g) ;
                        break;
                    case 4: // ��ת90+Y����
//                        g.drawRegion(img, 0, 0, img.getWidth(), img.getHeight(), 7, x - bx + img.getHeight(), y + by + img.getWidth(), 40);
                        DrawRegionJ2SE.drawRegionJ2SE(img, x - bx + img.getHeight(), y + by + img.getWidth(), trans, 40, g) ;
                        break;
                    case 5: // ��ת90
//                        g.drawRegion(img, 0, 0, img.getWidth(), img.getHeight(), 5, x - bx + img.getHeight(), y + by, 24);
                        DrawRegionJ2SE.drawRegionJ2SE(img,  x - bx + img.getHeight(), y + by, trans, 24, g) ;
                        break;
                    case 6: // ��ת270
//                        g.drawRegion(img, 0, 0, img.getWidth(), img.getHeight(), 6, x - bx, y + by + img.getWidth(), 36);
                        DrawRegionJ2SE.drawRegionJ2SE(img,x - bx, y + by + img.getWidth(), trans, 36, g) ;
                        break;
                    case 7: // ��ת270+Y����
//                        g.drawRegion(img, 0, 0, img.getWidth(), img.getHeight(), 4, x - bx, y + by, 20);
                        DrawRegionJ2SE.drawRegionJ2SE(img,x - bx, y + by, trans, 20, g) ;
                        break;
                    default:
                        System.out.println("2.0trans error");
                        break;
                }
            }
        }
    }
 
}
