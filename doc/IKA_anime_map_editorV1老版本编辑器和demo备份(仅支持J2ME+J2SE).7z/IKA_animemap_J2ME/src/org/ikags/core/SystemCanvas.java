package org.ikags.core;

import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;

/**
 * I.K.A Engine SystemCanvas��.
 * @author airzhangfish
 * @since 2005.11.15 ������ 2009.5.20
 * @version 0.6
 */
public class SystemCanvas extends Canvas implements Runnable
{

    private SystemMidlet midlet;
    private static boolean IsRun = true;
    private State mystate = null;

    /**
     * ��ʼ��
     */
    public SystemCanvas(SystemMidlet let, State state)
    {
        setFullScreenMode(true);
        midlet = let;
        mystate = state;
        Def.MainState = Def.STATE_LOGO;// ��ʼ״̬
        mystate.init();
        new Thread(this).start();
    }

    /**
     * ��ʾ��ǰ״̬��֡��
     */
    public static long show_fps;
    private static long thread_startTime;
    private static long thread_endTime;

    /**
     * ���߳����㺯��������keystate����״̬��repaint�¼��������ڻ滭���߼������¼���
     */
    public void run()
    {
        while (IsRun)
        {
            thread_startTime = System.currentTimeMillis();
            logic();
            repaint();
            thread_endTime = System.currentTimeMillis();
            try
            {
                if ((thread_endTime - thread_startTime) < Def.SYSTEM_DELAY)
                {
                    Thread.sleep(Def.SYSTEM_DELAY - (thread_endTime - thread_startTime));
                }
                else
                {
                    Thread.sleep(1);
                }
            }
            catch (InterruptedException ex1)
            {
            }
            show_fps = thread_endTime - thread_startTime;
        }
        midlet.destroyApp(true);
        midlet.notifyDestroyed();
    }

    /**
     * ������ʱ�����
     */
    public static void exit()
    {
        IsRun = false;
    }

    Graphics g;// bufImage�õ�G

    /**
     * ���滭����������滭״̬���Ƽ��ṹ���������壬setclip��cliprect����Ϸ״̬switch��
     */
    public void paint(Graphics fish)
    {
        if (Def.bufferImage == null)
        {
            fish.setFont(Def.font);
            fish.setClip(0, 0, Def.SYSTEM_SW, Def.SYSTEM_SH);
            fish.clipRect(0, 0, Def.SYSTEM_SW, Def.SYSTEM_SH);
            Def.SYSTEM_SW = this.getWidth();
            Def.SYSTEM_SH = this.getHeight();
            init(fish);
        }
        else
        {
            g = Def.bufferImage.getGraphics();
            g.setFont(Def.font);
            // g.setClip(0, 0, Def.SYSTEM_SW, Def.SYSTEM_SH);
            // g.clipRect(0, 0, Def.SYSTEM_SW, Def.SYSTEM_SH);

            mystate.paint(g);
            DisplayBufferImage(fish);
        }
    }

    /**
     * ������ keyPressed���������巵�ص�key���Ƽ��ṹ����Ϸ״̬switch��
     * @param key ���ػ���������Ϣ
     * @see Def
     */
    public void keyPressed(int key)
    {
        key = keyConvert(key);
        mystate.keyPressed(key);
    }

    /**
     * ���ͷŰ��� keyReleased���������巵�ص�key���Ƽ��ṹ����Ϸ״̬switch��
     * @param key ���ػ���������Ϣ
     * @see Def
     */
    public void keyReleased(int key)
    {
        key = keyConvert(key);
        mystate.keyReleased(key);
    }

    
    /**
     * ��������ק
     */
   public void pointerDragged(int x, int y)
    {
       mystate.pointerDragged(x,y);
    }

   /**
    * ����������
    */
    public void pointerPressed(int x, int y)
    {
        mystate.pointerPressed(x,y);
    }

    /**
     * �������ͷ�
     */
    public void pointerReleased(int x, int y)
    {
        mystate.pointerReleased(x,y);
    }

    
    /**
     * �����߼�����
     */
    private void logic()
    {
        mystate.Logic();
    }

    private int inicount = 0;

    /**
     * ���ȫ��BufferImage�ĳ�ʼ��
     * @param g
     */
    private void init(Graphics g)
    {
        Def.SYSTEM_SW = this.getWidth();
        Def.SYSTEM_SH = this.getHeight();
        g.setColor(0x000000);
        g.fillRect(0, 0, Def.SYSTEM_SW, Def.SYSTEM_SH);
        switch (inicount)
        {
            case 1:
                initBufferImage();
                break;
            case 2:
                Def.MainState = Def.STATE_LOGO;
                break;
        }
        inicount++;
    }

    /**
     * ���ⰴ��ת��,ͨ��Ŀǰ���������ֻ�����.ǿ�ƽ��ֻ��İ�����Ϣת��Ϊ������Ϣ,����Ҫ����ƥ��
     * @param keycode
     * @return
     */
    private int keyConvert(int keycode)
    {
        try
        {
            if (keycode >= 48 && keycode <= 57)
            {
                return keycode;
            }
            if (keycode == 42 || keycode == 35)
            {
                return keycode;
            }
            int gamekeycode = getGameAction(keycode);
            if (gamekeycode == Canvas.UP)
            {
                return Def.KEY_UP;
            }
            if (gamekeycode == Canvas.DOWN)
            {
                return Def.KEY_DOWN;
            }
            if (gamekeycode == Canvas.LEFT)
            {
                return Def.KEY_LEFT;
            }
            if (gamekeycode == Canvas.RIGHT)
            {
                return Def.KEY_RIGHT;
            }

            if (keycode == -20 || keycode == 20 || keycode == -5 || keycode == 5 || keycode == 8)
            {
                return Def.KEY_MIDDLE;
            }
            if (keycode == -21 || keycode == 21 || keycode == -6 || keycode == 6)
            {
                return Def.SOFTKEY_LEFT;
            }

            if (keycode == -22 || keycode == 22 || keycode == -7 || keycode == 7)
            {
                return Def.SOFTKEY_RIGHT;
            }

            if (keycode == -8)
            {
                return Def.KEY_CLEAR;
            }
        }
        catch (Exception ex)
        {
            return keycode;
        }
        return keycode;
    }

    /**
     * ��Ҫ�ı�������Ļ����Ļ�������������,�������ΪTOPin��ز���
     * @param theway
     * @return boolean
     */
    public static boolean ChangeTheWay(int theway)
    {
        switch (theway)
        {
            case Def.TOPinNORMAL:
                Def.SYSTEM_SW = Def.DEFAULT_SYSTEM_SW;
                Def.SYSTEM_SH = Def.DEFAULT_SYSTEM_SH;
                Def.bufferImage = Image.createImage(Def.SYSTEM_SW, Def.SYSTEM_SH);
                Def.TheWay = Def.TOPinNORMAL;
                break;
            case Def.TOPinLEFT:
                Def.SYSTEM_SW = Def.DEFAULT_SYSTEM_SH;
                Def.SYSTEM_SH = Def.DEFAULT_SYSTEM_SW;
                Def.bufferImage = Image.createImage(Def.SYSTEM_SW, Def.SYSTEM_SH);
                Def.TheWay = Def.TOPinLEFT;
                break;
            case Def.TOPinRIGHT:
                Def.SYSTEM_SW = Def.DEFAULT_SYSTEM_SH;
                Def.SYSTEM_SH = Def.DEFAULT_SYSTEM_SW;
                Def.bufferImage = Image.createImage(Def.SYSTEM_SW, Def.SYSTEM_SH);
                Def.TheWay = Def.TOPinRIGHT;
                break;
            case Def.TOPinBOTTOM:
                Def.SYSTEM_SW = Def.DEFAULT_SYSTEM_SW;
                Def.SYSTEM_SH = Def.DEFAULT_SYSTEM_SH;
                Def.bufferImage = Image.createImage(Def.SYSTEM_SW, Def.SYSTEM_SH);
                Def.TheWay = Def.TOPinBOTTOM;
                break;
        }
        return true;
    }

    /**
     * ��BufferImage�滭����Ļ(����ת)<BR>
     * ʹ�÷���:<BR>
     * Graphics gg;//bufImage�õ�G<BR>
     * gg=Def.bufferImage.getGraphics();//��ȡgg<BR>
     * gg.drawString("�滭��BUFF��",0,0,0);<BR>
     * Def.DisplayBufferImage(g);//ԭʼ�Ļ滭g<BR>
     * @param g
     */
    private void DisplayBufferImage(Graphics g)
    {
        switch (Def.TheWay)
        {
            case Def.TOPinNORMAL:
                g.drawImage(Def.bufferImage, 0, 0, 0);
                break;
            case Def.TOPinLEFT:
                g.drawRegion(Def.bufferImage, 0, 0, Def.bufferImage.getWidth(), Def.bufferImage.getHeight(), 6, 0, 0, 0);
                break;
            case Def.TOPinRIGHT:
                g.drawRegion(Def.bufferImage, 0, 0, Def.bufferImage.getWidth(), Def.bufferImage.getHeight(), 5, 0, 0, 0);
                break;
            case Def.TOPinBOTTOM:
                g.drawRegion(Def.bufferImage, 0, 0, Def.bufferImage.getWidth(), Def.bufferImage.getHeight(), 3, 0, 0, 0);
                break;
        }
    }

    /**
     * ��ʼ������
     * @param path
     * @return �Ƿ�ɹ���ȡ
     */
    private boolean initBufferImage()
    {
        Def.DEFAULT_SYSTEM_SW = Def.SYSTEM_SW;
        Def.DEFAULT_SYSTEM_SH = Def.SYSTEM_SH;
        Def.bufferImage = Image.createImage(Def.SYSTEM_SW, Def.SYSTEM_SH);
        return true;
    }

}
