package org.ikags.util;

import java.io.InputStream;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;

    /**
     * ������ͼ���ƺ��¼��жϵ�����<BR>
     * ��ʼ������:<BR>
     * com.ika.util.MapTools map=new com.ika.util.MapTools("/liangmap.map","/lianmap.bin",0);<BR>
     * ʹ�û滭����:<BR>
     * map.paint(g);<BR>
     * ��������:<BR>
     * if (key == Def.KEY_DOWN)<BR> {<BR>
     * if (map.talkMode != true)<BR> {<BR>
     * map.MoveState = 4;//�ƶ�״̬<BR>
     * ani2.AnimeSelect = 1;//����״̬�ı�<BR> }<BR> }<BR>
     * map.keyTalk(key);//�Ի����밴��<BR>
     * 
     * 
     * 
     * @param mappath ��ͼ�ļ�·��
     * @param imgpath ͼƬ�ļ�·��
     */
public class MapTools
{


    public MapTools(String mappath, String imgpath, int MapID)
    {
        this.MapID = MapID;
        loadmap_matrix(mappath);
        MAPIMG = load_Image(imgpath);
        mapTilesCount = MAPIMG.length;
    }

    private int skipint0 = 0;// i
    private int skipint1 = 0;// k
    private int skipint2 = 0;// a

    /**
     * �����ͼ����
     */
    private void loadmap_matrix(String path)
    {
        try
        {
            InputStream is = this.getClass().getResourceAsStream(path);
            skipint0 = is.read();
            skipint1 = is.read();
            skipint2 = is.read();
            if (skipint0 == 73 && skipint1 == 75 && skipint2 == 65)
            {// ��֤�Ƿ���ika�༭���ĵ�ͼ�ļ�
            }
            skipint0 = is.read();
            skipint0 = is.read();// ����ȥ����δ����2byte
            TILE_WIDTH = (is.read() << 8) + is.read();// ����
            TILE_HEIGHT = (is.read() << 8) + is.read();// ��鳤
            max_tile_width = (is.read() << 8) + is.read();// ��ͼ��
            max_tile_height = (is.read() << 8) + is.read();// ��ͼ��
            map_matrix = new byte[max_tile_width][max_tile_height];
            map_colandtran = new byte[max_tile_width][max_tile_height];
            for (int i = 0; i < max_tile_width; i++)
            {
                for (int j = 0; j < max_tile_height; j++)
                {
                    map_colandtran[i][j] = ( byte ) is.read();
                    map_matrix[i][j] = ( byte ) is.read();
                }
            }
            // max_StartedX = -max_tile_width * N_MAZE_ELEMENT_WIDTH + wdith + 25;
            // max_StartedY = -max_tile_height * N_MAZE_ELEMENT_HEIGHT + height + 10;
        }
        catch (Exception e)
        {
            System.out.println("loadmap_matrix  error:" + path);
            e.printStackTrace();
        }
    }

    /**
     * ��ͼͼƬ (Сͼ)
     */
    public Image[] MAPIMG; // ��ͼͼƬ (Сͼ)

    /**
     * �����ͼͼƬ
     */
    private static Image[] load_Image(String path)
    {
        // ��ȡͼƬ
        Image[] imgs = null;
        InputStream is = "i".getClass().getResourceAsStream(path);
        try
        {
            int total_picnumber = (is.read() << 8) + is.read();
            imgs = new Image[total_picnumber];
            for (int i = 0; i < total_picnumber; i++)
            {
                byte[] image_matrix;
                int image_length = (is.read() << 8) + is.read();
                image_matrix = new byte[image_length];
                is.read(image_matrix, 0, image_length);
                imgs[i] = Image.createImage(image_matrix, 0, image_length);
            }
        }
        catch (Exception e)
        {
            System.out.println("images read error:" + path);
            e.printStackTrace();
        }
        return imgs;
    }

    public int MapID = 0;
    public int StartedX = 0; // ����Ļ�Ͽ�ʼ�滭�����Ͻǵľ�������X��һ��Ϊ����
    public int StartedY = 0; // ����Ļ�Ͽ�ʼ�滭�����Ͻǵľ�������Y��һ��Ϊ����
    public int max_tile_width; // ��ͼ��������ܺ�
    public int max_tile_height; // ��ͼ�߶�����ܺ�
    public int mapTilesCount = 0;
    public int TILE_WIDTH = 0; // ������
    public int TILE_HEIGHT = 0; // ���߶�
    public byte[][] map_matrix; // ��ȡ��ĵ�ͼ���ݣ���ʼ��ʱ��Ϊ��
    public byte[][] map_colandtran; // ��ת��ײ��Ϣ
    public int draw_row = 0; // ÿ�ж��ٸ����
    public int draw_line = 0; // ÿ�ж��ٸ����

    /**
     * �滭����
     * 
     * @param g
     */
    public void paint(int wdith ,int height,Graphics g)
    {
        draw_row = (wdith / TILE_WIDTH) + 2;
        draw_line = (height / TILE_HEIGHT) + 2;
        if (talkMode != true)
        {
            PlayerMove();
        }
        draw_Normal_Map(MAPIMG, map_matrix, draw_row, draw_line, g,wdith,height);
        drawPlayer(g);
        drawTalkBox(wdith,height,g);
        System.gc();
    }

    /**
     * ��ͷ��Χ��,�Զ�����player����
     */
    public void CameraAuto(int wdith ,int height)
    {
        int left_W = wdith / 4;
        int left_H = height / 4;
        int x = playerX - (playerWidth / 2);
        int y = playerY - playerHeight;// playerWidth, playerHeight
        if (x < left_W)
        {
            CameraMove(3, StepSpeed);
            playerX = playerX + StepSpeed;
        }
        if (x + playerWidth > wdith - left_W)
        {
            CameraMove(4, StepSpeed);
            playerX = playerX - StepSpeed;
        }
        if (y < left_H)
        {
            CameraMove(1, StepSpeed);
            playerY = playerY + StepSpeed;
        }
        if (y + playerHeight > height - left_H)
        {
            CameraMove(2, StepSpeed);
            playerY = playerY - StepSpeed;
        }
    }

    /**
     * ��ͷ�ƶ�
     * 
     * @param dir
     * @param speed
     */
    public void CameraMove(int dir, int speed)
    {
        switch (dir)
        {
            case 1:// ��
                StartedY = StartedY + speed;
                break;
            case 2:// ��
                StartedY = StartedY - speed;
                break;
            case 3:// ��
                StartedX = StartedX + speed;
                break;
            case 4:// ��
                StartedX = StartedX - speed;
                break;
        }
    }

    private boolean frame_col = false;// ��֡�Ƿ���ײ

    /**
     * ��ͨ��������ͼ����(�Ͽ����巨��ʱ����,��Ϊ��Щ������֧��,��Ҫ�ֶ�����)
     */
    private void draw_Normal_Map(Image[] mapimg, byte[][] mapbox, int Array_width, int Array_heigh, Graphics g,int width ,int height)
    {
        frame_col = false;
        int nArrayI = (-TILE_HEIGHT - StartedX) / TILE_HEIGHT;
        int nArrayJ = (-TILE_WIDTH - StartedY) / TILE_WIDTH;
        for (int i = nArrayI; i <= Array_width + nArrayI; i++)
        {
            for (int j = nArrayJ; j <= Array_heigh + nArrayJ; j++)
            {
                if (i < 0 || i >= mapbox.length || j < 0 || j >= mapbox[0].length)
                {
                    continue;
                }
                else
                {
                    int bX = StartedX + (i * TILE_WIDTH);
                    int bY = StartedY + (j * TILE_HEIGHT);
                    int col = map_colandtran[i][j];
                    boolean colthis = false;
                    if (col > 15)
                    {
                        // ��ײΪtrue
                        colthis = true;
                        col = col - 16;
                    }
                    drawMapImage(mapimg, mapbox[i][j], bX, bY, col, g);
                    if (colthis == true)
                    {
                        //TODO ��ײ���
//                        g.drawString("��", bX, bY, 0);// �����ײ
                    }
                    // �¼�����
                    int x = playerX - (playerWidth / 2);
                    int y = playerY - playerHeight;
                    // ��ײ����
                    g.setColor(0xffffff);
                    g.drawRect(x - (TILE_WIDTH / 2), y - (TILE_HEIGHT / 2), playerWidth * 2, playerHeight * 2);
                    if (cls_boxbox(x, y, playerWidth, playerHeight, bX, bY, TILE_WIDTH, TILE_HEIGHT))
                    {
                        switchthings(i, j, MapID, g);
                        if (colthis == true)
                        {
                            frame_col = true;
                        }
                    }
                }
            }
        }
        // ��ͼ����ص����
        for (int i = nArrayI; i <= draw_row + nArrayI; i++)
        {
            for (int j = nArrayJ; j <= draw_line + nArrayJ; j++)
            {
                if (i < 0 || i >= mapbox.length || j < 0 || j >= mapbox[0].length)
                {
                    continue;
                }
                else
                {
                    int bX = StartedX + (i * TILE_WIDTH);
                    int bY = StartedY + (j * TILE_HEIGHT);
                    drawSpecial(i, j, bX, bY, MapID, g);
                }
            }
        }
        if (frame_col == true)
        {
            playerX = lastframe_playerX;
            playerY = lastframe_playerY;
        }
        else
        {
            CameraAuto(width,height);
            lastframe_playerX = playerX;
            lastframe_playerY = playerY;
        }
    }

    private boolean isTalk(byte[][] mapbox, int Array_width, int Array_heigh)
    {
        int nArrayI = (-TILE_HEIGHT - StartedX) / TILE_HEIGHT;
        int nArrayJ = (-TILE_WIDTH - StartedY) / TILE_WIDTH;
        for (int i = nArrayI; i <= draw_row + nArrayI; i++)
        {
            for (int j = nArrayJ; j <= draw_line + nArrayJ; j++)
            {
                if (i < 0 || i >= mapbox.length || j < 0 || j >= mapbox[0].length)
                {
                    continue;
                }
                else
                {
                    int bX = StartedX + (i * TILE_WIDTH);
                    int bY = StartedY + (j * TILE_HEIGHT);
                    // �¼�����
                    int x = playerX - (playerWidth / 2);
                    int y = playerY - playerHeight;
                    // �Ի���Χ����
                    if (cls_boxbox(x - (TILE_WIDTH / 2), y - (TILE_HEIGHT / 2), playerWidth * 2, playerHeight * 2, bX, bY, TILE_WIDTH, TILE_HEIGHT))
                    {
                        System.out.println("is cls_boxbox");
                        boolean istalk = talk(i, j, MapID);
                        if (istalk == true)
                        {
                            return istalk;
                        }
                    }
                }
            }
        }
        return false;
    }

    
    private static boolean cls_boxbox(int tx, int ty, int tw, int th, int fx, int fy, int fw, int fh)
    {
        if (tw + tx >= fx && tx <= fx + fw && ty + th >= fy && ty <= fy + fh)
        {
            return true;
        }
        return false;
    }
    
    
    public void keyTalk(int key)
    {
        if (key == 53 || key == -5)//key == Def.KEY_MIDDLE || key == Def.KEY_5
        {
            System.out.println("talkMode:" + talkMode);
            if (talkMode)
            {
                talkMode = false;
            }
            else
            {
                boolean gotoTalkMode = isTalk(map_matrix, draw_row, draw_line);
                if (gotoTalkMode == true)
                {
                    talkMode = true;
                }
            }
        }
    }

    public int playerX = 0;
    public int playerY = 0;
    public int playerWidth = 32;
    public int playerHeight = 32;
    public int lastframe_playerX = 0;
    public int lastframe_playerY = 0;
    public int StepSpeed = 4;
    public int MoveState = 0;

    /**
     * player�ƶ�
     */
    public void PlayerMove()
    {
        switch (MoveState)
        {
            case 1:
                playerX = playerX - StepSpeed;
                break;
            case 2:
                playerX = playerX + StepSpeed;
                break;
            case 3:
                playerY = playerY - StepSpeed;
                break;
            case 4:
                playerY = playerY + StepSpeed;
                break;
            case 0:
                break;
        }
    }

    // ��С���
    private void drawMapImage(Image[] img, int tile_number, int draw_x, int draw_y, int direction, Graphics g)
    {
        if (direction == 0)
        {
            g.drawImage(img[tile_number], draw_x, draw_y, 0);
        }
        else
        {
            switch (direction)
            {
                case 1:
                    g.drawRegion(img[tile_number], 0, 0, TILE_WIDTH, TILE_HEIGHT, 2, draw_x, draw_y, 0);
                    break;
                case 2:
                    g.drawRegion(img[tile_number], 0, 0, TILE_WIDTH, TILE_HEIGHT, 1, draw_x, draw_y, 0);
                    break;
                case 3:
                    g.drawRegion(img[tile_number], 0, 0, TILE_WIDTH, TILE_HEIGHT, direction, draw_x, draw_y, 0);
                    break;
                case 4:
                    g.drawRegion(img[tile_number], 0, 0, TILE_WIDTH, TILE_HEIGHT, 7, draw_x, draw_y, 0);
                    break;
                case 5:
                    g.drawRegion(img[tile_number], 0, 0, TILE_WIDTH, TILE_HEIGHT, direction, draw_x, draw_y, 0);
                    break;
                case 6:
                    g.drawRegion(img[tile_number], 0, 0, TILE_WIDTH, TILE_HEIGHT, direction, draw_x, draw_y, 0);
                    break;
                case 7:
                    g.drawRegion(img[tile_number], 0, 0, TILE_WIDTH, TILE_HEIGHT, 4, draw_x, draw_y, 0);
                    break;
            }
        }
    }

    // ***********************************************************//
    // ***********************************************************//
    // ********************��Ҫ�Լ������Ĵ���**********************//
    // ***********************************************************//
    // ***********************************************************//
    // ***********************************************************//
    /**
     * �������.������д�˷���
     * 
     * @param g
     */
    public void drawPlayer(Graphics g)
    {
        // TODO ��������
        g.setColor(0xffffff);
        g.drawRect(playerX - (playerWidth / 2), playerY - playerHeight, playerWidth, playerHeight);
    }

/**
 * �¼�����,��ͼ�����ﴦ��(��ײ����,���ս���ȵ�)
 * @param i
 * �˵�ͼ��������ĺ�������
 * @param j
 * �˵�ͼ�����������������
 * @param mapID
 * ��ͼID
 * @param g
 */
    public void switchthings(int i, int j, int mapID, Graphics g)
    {
        // TODO �¼�����,�������,���뷿��,����ս���ȵ�
        if (i == 0 && j == 0)
        {
            return;
        }
    }

    /**
     * ��ͼ������Ʒ(С��)����,NPC,��ͼ��ڵȵ�
     * 
     * @param i
     * @param j
     * @param x
     * @param y
     * @param mapID
     * @param g
     */
    public void drawSpecial(int i, int j, int x, int y, int mapID, Graphics g)
    {
        // TODO ��ͼ������Ʒ(С��)����,NPC,��ͼ��ڵȵ�
        if (i == 3 && j == 3 && mapID == 0)
        {
// Image img=null;
// g1.drawImage(img, x, y, 0);
           
            g.fillRect(x, y, 32, 32);
            return;
        }
    }

    /**
     * ����Ի� ����
     * 
     * @param i
     * @param j
     * @param mapID
     */
    public boolean talk(int i, int j, int mapID)
    {
        // TODO ����Ի�
        if (i == 3 && j == 3 && mapID == 0)
        {
            // һ���drawSpecialһ����.NPC�ĶԻ�������������
            talkstr = "asdasdasdasdsad";
            return true;
        }
        return false;
    }

    public String talkstr = "";
    public boolean talkMode = false;

    /**
     * ���ƶԻ����
     * 
     * @param g
     */
    public void drawTalkBox(int wdith ,int height,Graphics g)
    {
        if (talkMode)
        {
            g.setColor(0xffffff);
            g.fillRect(0, height - (height / 4), wdith, height / 4);
            g.setColor(0x000000);
            g.drawString("" + talkstr, 0, height - (height / 4), 0);
        }
    }
}
