package org.ikags.simple;

import org.ikags.core.SystemMidlet;

/**
 * I.K.A Engine midlet simple
 * @author http://airzhangfish.spaces.live.com
 * @since 2009.5.20
 * @version 0.6
 */
public class SimpleMIDlet extends SystemMidlet
{
/**
 * 
 */
    public SimpleMIDlet()
    {
        this.init(DrawCanvas.getInstance());
    }


}
