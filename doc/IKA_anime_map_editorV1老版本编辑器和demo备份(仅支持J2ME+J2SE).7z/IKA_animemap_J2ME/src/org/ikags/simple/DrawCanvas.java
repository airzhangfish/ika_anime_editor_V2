package org.ikags.simple;

import javax.microedition.lcdui.Graphics;

import org.ikags.core.Def;
import org.ikags.core.State;
import org.ikags.util.MapTools;
import org.ikags.util.anime.*;

/**
 * I.K.A Engine DrawCanvas��<BR>
 * �������³�����,��ǰ����ҵ���޹�,
 * @author http://airzhangfish.spaces.live.com
 * @since 2005.11.15 ������ 2009.5.20
 * @version 0.6
 */
public class DrawCanvas extends State
{

    public static DrawCanvas drawCanvas;
/**
 * ����,��ȡʵ��.
 * @return
 */
    public static DrawCanvas getInstance()
    {
        if (drawCanvas == null)
        {
            drawCanvas = new DrawCanvas();
        }
        return drawCanvas;
    }
/**
 * �����߼�����
 */
    public void Logic()
    {

    }
/**
 * ������ʼ������
 */
    
    
    MapTools map=null;
    GSprite gsprite;
    public void init()
    {
        
        //��ͼ��ʼ��
     map=new MapTools("/testmap_data.map","/testmap_imgpak.bin",0);
        //������ʼ��
     AnimeEngine.getInstance().imgSprite_pool[0]=new AnimeSprite("/anime_simple.ika","/anime_imgpak.bin");
     gsprite=new GSprite(Def.SYSTEM_SW/2,Def.SYSTEM_SH-100,0,0,true);
        
        
    }
/***
 * ����keyPressed����
 */
    
   int showID=0;
    public boolean keyPressed(int key)
    {
        
        showID++;
        showID=showID%2;
        
        
        return false;
    }
    /***
     * ����keyReleased����
     */
    public boolean keyReleased(int key)
    {
        return false;
    }
/**
 * ��������
 */
    public void paint(Graphics g)
    {
    g.setColor(0x000000);
    g.fillRect(0, 0, Def.SYSTEM_SW, Def.SYSTEM_SH);
    g.setColor(0xffffff);
    switch(showID){
        case 0:
            
            //��ͼչʾ
            g.drawString("map", 0, 0, 0);
            map.paint(Def.SYSTEM_SW, Def.SYSTEM_SH, g);
            break;
        case 1:
            //����չʾ
            g.drawString("anime", 0, 0, 0);
            gsprite.paint(g);
        break;
    }
  
    
    }
public boolean pointerDragged(int x, int y)
{
    // TODO Auto-generated method stub
    return false;
}
public boolean pointerPressed(int x, int y)
{
    // TODO Auto-generated method stub
    return false;
}
public boolean pointerReleased(int x, int y)
{
    // TODO Auto-generated method stub
    return false;
}

}
