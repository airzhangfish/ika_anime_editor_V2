package util.anime;

import java.io.InputStream;
import java.util.HashMap;

import util.ConvertUtil;
import util.DrawRegionAndroid;
import util.anime.info.AnimeInfo;
import util.anime.info.FrameInfo;
import util.anime.info.ModInfo;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.Log;

/**
 * I.K.A Engine<BR>
 * AnimeEngine�࣬���������࣬�Ͷ���������<BR>
 * ʹ�÷���:<BR>
 * ��������:<BR>
 * AnimeEngine.imgSprite_pool[0]=new AnimeSprite("/logo.ika","/logo.bin");<BR>
 * GSprite gsprite=new GSprite(104,136,0,0,true);<BR>
 * ʹ�÷���:<BR>
 * gsprite.paint(g);<BR>
 * �����ڴ淽��:<BR>
 * gsprite=null;<BR>
 * AnimeEngine.imgSprite_pool[0].setNull();<BR>
 * AnimeEngine.imgSprite_pool[0]=null;<BR>
 * System.gc();<BR>
 * @author http://airzhangfish.spaces.live.com
 * @since 2005.11.15 ������ 2009.5.20
 * @version 0.6
 */
public class AnimeEngine
{
  Context mContext=null;
    private static AnimeEngine ae = null;

    public static AnimeEngine getInstance()
    {
        if (ae == null)
        {
            ae = new AnimeEngine();
        }
        return ae;
    }
    
    
    public static AnimeEngine getInstance(Context context)
    {
        if (ae == null)
        {
            ae = new AnimeEngine(context);
        }
        return ae;
    }
    
    
    public AnimeEngine(Context context){
      mContext=context;
    }

    /**
     * ������,���ڴ��涯��,Ĭ��9��ռ�
     */
    public AnimeSprite[] imgSprite_pool = new AnimeSprite[9];

    /**
     * ��ʼ��
     */
    public AnimeEngine()
    {
    }

    /**
     * ����ͼƬ��ȡ
     * @param path ͼƬbin�ļ�·��
     * @param img_sprite ����������
     */
    public void load_Image(String path, AnimeSprite img_sprite)
    { // ����ͼƬ��ȡ
        // ��ȡͼƬ
  
        try
        {
          InputStream is= mContext.getAssets().open(path);
            byte[] piece=new byte[4];
            piece[0]=(byte)is.read();
            piece[1]=(byte)is.read();
            piece[2]=(byte)is.read();
            piece[3]=(byte)is.read();
            img_sprite.anime_Piece = ConvertUtil.bytesToInt(piece);
            System.out.println("total PNG:" + img_sprite.anime_Piece);
            img_sprite.AnimeImg = new Bitmap[img_sprite.anime_Piece];
            for (int i = 0; i < img_sprite.anime_Piece; i++)
            {
                byte[] image_matrix;
                byte[] bys=new byte[4];
                bys[0]=(byte)is.read();
                bys[1]=(byte)is.read();
                bys[2]=(byte)is.read();
                bys[3]=(byte)is.read();
                int image_length = ConvertUtil.bytesToInt(bys);
                System.out.println(i+" png size=" + image_length);
                image_matrix = new byte[image_length];
                is.read(image_matrix, 0, image_length);
//                img_sprite.AnimeImg[i] = Image.createImage(image_matrix, 0, image_length);
                img_sprite.AnimeImg[i]=BitmapFactory.decodeByteArray(image_matrix, 0, image_length);
            }
        }
        catch (Exception e)
        {
            System.out.println("images read error");
        }
    }

    /**
     * ���������ļ���ȡ
     * @param path ͼƬbin�ļ�·��
     * @param img_sprite ����������
     */
    public void load_Anime(String path, AnimeSprite img_sprite)
    {
        short[] inputintdata;
        try
        {
//            InputStream fo = "i".getClass().getResourceAsStream(path);
          InputStream fo= mContext.getAssets().open(path);
          Log.v("anime_read","START-1="+fo.available());
          //��ȡbytes
            inputintdata = new short[(fo.available()-3) / 2];
            //�������ͷ�ֶ�
            fo.read();
            fo.read();
            fo.read();
            for (int i = 0; i < inputintdata.length; i++)
            {
            	inputintdata[i] =getShort(fo);
            }
            fo.close();

            //��ȡframe
            Log.v("anime_read","START-2");
            int pos=0;
            int framelength = inputintdata[pos];
            pos++;
            img_sprite.mFramelist=new FrameInfo[framelength];
            Log.v("anime_read","START-framelength,"+framelength);
            for (int i = 0; i < framelength; i++)
            {

            	img_sprite.mFramelist[i]=new FrameInfo();
                int modlistlength = inputintdata[pos];
                Log.v("anime_read","START-3,"+i+","+modlistlength);
                pos++;
            	img_sprite.mFramelist[i].mModlist=new ModInfo[modlistlength];
            	for(int j=0;j<modlistlength;j++){
            		 int modlength =  inputintdata[pos];
                     pos++;
            		img_sprite.mFramelist[i].mModlist[j]=new ModInfo();
            		img_sprite.mFramelist[i].mModlist[j].mImageModID= inputintdata[pos];
                    pos++;
            		img_sprite.mFramelist[i].mModlist[j].mX= inputintdata[pos];
                    pos++;
            		img_sprite.mFramelist[i].mModlist[j].mY= inputintdata[pos];
                    pos++;
            		img_sprite.mFramelist[i].mModlist[j].mRotate= inputintdata[pos];
                    pos++;
            		img_sprite.mFramelist[i].mModlist[j].mScale=((float)inputintdata[pos])/10;
                     pos++;
            		img_sprite.mFramelist[i].mModlist[j].mRotateType= inputintdata[pos];
                    pos++;
            	}
            }
            
            //��ȡanime
            int animelistlength = inputintdata[pos];
            pos++;
         	Log.v("ANIME", "animelistlength="+animelistlength);
            img_sprite.mAnimelist=new AnimeInfo[animelistlength];
            for (int i = 0; i < animelistlength; i++)
            {
            	img_sprite.mAnimelist[i]=new AnimeInfo();
                int frameidlistlength = inputintdata[pos];
                pos++;
            	img_sprite.mAnimelist[i].mFrameIDlist=new int[frameidlistlength];
            	for(int j=0;j<frameidlistlength;j++){
//            		 int framepiecelength = inputintdata[pos];
//                     pos++;
            		img_sprite.mAnimelist[i].mFrameIDlist[j]=inputintdata[pos];
                    pos++;
            	}
            	Log.v("ANIME", i+",animesize="+frameidlistlength);
            	img_sprite.mAnimelist[i].printList();
            	
            }

            System.out.println("read ika over");
        }
        catch (Exception ex)
        {
            System.out.println("read ika error");
        }
        inputintdata = null;
    }

    
    public short getShort(InputStream fo){
    	short tmpshort=0;
    	byte[] bytes=new byte[2];
    	try{
    	bytes[0]=(byte)fo.read();
    	bytes[1]=(byte)fo.read();
    	tmpshort =ConvertUtil.bytesToShort(bytes);
    	}catch(Exception ex){
    		ex.printStackTrace();
    	}
    	return tmpshort;
    }
    
    
    /**
     * ��ʵ�滭��֡
     */
    private int frame_select;
    /**
     * ��������ID
     */
    public int ActSecletNumber = 0;
    /**
     * ��ǰ֡
     */
    public int act_frame = 0;
    /**
     * ��������
     */
    public boolean isleft = true;
/**
 *  ��������
 */
    public float frame_scale = 1f;
    /**
     * �滭����
     * @param g
     * @param x ����
     * @param y ����
     * @param img_sprite ����������
     */
    public void paint(Canvas g, int x, int y, AnimeSprite img_sprite,HashMap<Integer, Bitmap> mReplaceMap)
    {
        if (ActSecletNumber >= 0)
        {
  
        	AnimeInfo mAnime= img_sprite.mAnimelist[ActSecletNumber];
        	frame_select= mAnime.mFrameIDlist[act_frame%mAnime.mFrameIDlist.length];
        	FrameInfo mFrame=img_sprite.mFramelist[frame_select];
            for (int i = 0; i < mFrame.mModlist.length; i++)
            {
            	ModInfo mod=mFrame.mModlist[i];
            	if(mReplaceMap==null){
            		  drawAni(img_sprite.AnimeImg[mod.mImageModID], x, mod.mX, y,mod.mY,mod.mRotate,mod.mScale,frame_scale, isleft, g); 	
            	}else{
            		//�滻ģʽ
            		Bitmap bitmap=mReplaceMap.get(mod.mImageModID);
            		if(bitmap!=null){
            			  drawAni(bitmap, x, mod.mX, y,mod.mY,mod.mRotate,mod.mScale,frame_scale, isleft, g); 	
            		}else{
            			 drawAni(img_sprite.AnimeImg[mod.mImageModID], x, mod.mX, y,mod.mY,mod.mRotate,mod.mScale,frame_scale, isleft, g); 	
            		}
            		}
                }
            act_frame++;
        }
    }

   
    Paint mPaint=new Paint();
    
    /**
     * �����õ���淽�� MIDP2.0ʹ��.(nokia api�汾��ͨ����,��ʱ����)
     */
    private void drawAni(Bitmap img, int x, int bx, int y, int by, int rot,float scale, float framescale,boolean isleft, Canvas g)
    {
    	DrawRegionAndroid.drawRegion(img, x ,y, bx, by, rot, scale,framescale, isleft,g, mPaint);
    }
    

    
    
}
