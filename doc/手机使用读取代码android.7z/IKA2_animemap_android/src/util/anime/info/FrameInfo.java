package util.anime.info;


public class FrameInfo {
	public ModInfo[] mModlist= null;
	
	
}
