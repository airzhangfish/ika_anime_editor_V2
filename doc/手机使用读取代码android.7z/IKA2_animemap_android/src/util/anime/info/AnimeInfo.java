package util.anime.info;

import android.util.Log;

public class AnimeInfo{
	public int[] mFrameIDlist = null;
	
	public void printList(){
		if(mFrameIDlist!=null){
			StringBuffer sb=new StringBuffer();
			for(int i=0;i<mFrameIDlist.length;i++){
				sb.append(mFrameIDlist[i]);
				sb.append(",");
			}
			String data=sb.toString();
			Log.v("AnimeInfo", "frameidlist="+data);
		}
	}

}
