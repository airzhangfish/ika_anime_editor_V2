package util.anime;

import java.util.HashMap;

import util.anime.info.AnimeInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;



/**
 * I.K.A Engine<BR>
 * GSprite�࣬��Ϸ�����ֱ࣬�ӵ��ö�����<BR>
 * ʹ�÷����μ�AnimeEngine��˵��
 * @author http://airzhangfish.spaces.live.com
 * @since 2005.11.15 ������ 2009.5.20
 * @version 0.6
 */
public class GSprite
{

	/**
	 * ͼƬ�滻(�滻������)
	 */
	public HashMap<Integer, Bitmap> mReplaceMap=null; 
	public int skipFrame=0; //0Ϊ����֡
    /**
     * ����ID
     */
    public int ActSecletNumber = 0;
    /**
     * ֡ID
     */
    public int act_frame = 0;
    private int act_skipcount = 0;
    /**
     * ��������
     */
    public boolean isFaceRight = true;
    /**
     * ���ö���ID
     */
    public int ImageSpriteID = 0;
    /**
     * ����
     */
    public int x = 0;
    public int y = 0;
    /**
     * ��������
     */
    public float frameScale=1f;
    /**
     * ��Ϸ�����ʼ����Դ
     */
    public GSprite(int xx, int yy, int ImageSID, int aniselect, boolean left)
    {
        ImageSpriteID = ImageSID;
        ActSecletNumber = aniselect;
        isFaceRight = left;
        x = xx;
        y = yy;
    }
    /**
     * ��Ϸ����滭
     */
    public void paint(Canvas g)
    {
        AnimeEngine.getInstance().ActSecletNumber = ActSecletNumber;
        AnimeEngine.getInstance().act_frame = act_frame;
        AnimeEngine.getInstance().isleft = isFaceRight;
        AnimeEngine.getInstance().frame_scale=frameScale;
        AnimeEngine.getInstance().paint(g, x, y, AnimeEngine.getInstance().imgSprite_pool[ImageSpriteID],mReplaceMap);
        
        if(act_skipcount<skipFrame){
        	act_skipcount++;
        }else{
        	act_skipcount=0;
        	   act_frame = AnimeEngine.getInstance().act_frame;	
        }
        //act_frame = AnimeEngine.getInstance().act_frame;
    }
    
    public int getActFrameCount(){
    	int count=0;
    	try{
     	AnimeInfo mAnime= AnimeEngine.getInstance().imgSprite_pool[ImageSpriteID].mAnimelist[ActSecletNumber];
    	count=mAnime.mFrameIDlist.length;
    	}catch(Exception ex){
    		ex.printStackTrace();
    	}
    	return count;
    }
    
    public int getCurrentFrame(){
    	int count=getActFrameCount();
    	if(count>0){
    		return act_frame%count;
    	}
    	return 0;
    }
}
