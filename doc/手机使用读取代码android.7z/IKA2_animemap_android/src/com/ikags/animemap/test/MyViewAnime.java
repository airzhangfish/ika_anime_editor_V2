package com.ikags.animemap.test;


import java.util.HashMap;

import util.anime.AnimeEngine;
import util.anime.AnimeSprite;
import util.anime.GSprite;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.SurfaceHolder.Callback;

public class MyViewAnime extends SurfaceView implements Runnable, Callback
{

  Paint paint = new Paint();
  SurfaceHolder mSurfaceHolder = null;
  Context mcontext = null;

  Bitmap myBmp;
  int dog_x = 0;
  int dog_y = 0;
  int xss = 0;
  
  GSprite gsprite=null;
  GSprite gsprite2=null;
  GSprite gsprite3=null;
  GSprite gsprite4=null;
  public static String text = "moving text";
  
  public MyViewAnime(Context context)
  {
    super(context);
    mSurfaceHolder = getHolder();
    mSurfaceHolder.addCallback(this);
    mcontext = context;

    
    
    AnimeEngine.getInstance(context);
//  AnimeEngine.getInstance().imgSprite_pool[0]=new AnimeSprite("anime_simple.ika","anime_imgpak.bin");
  AnimeEngine.getInstance().imgSprite_pool[0]=new AnimeSprite("ss.ika","ss.bin");
  gsprite=new GSprite(250,150,0,2,true);
  gsprite2=new GSprite(100,150,0,2,true);
  gsprite3=new GSprite(100,350,0,2,false);
  gsprite4=new GSprite(250,350,0,2,false);
  try{
  Bitmap bit0=BitmapFactory.decodeStream(this.getContext().getAssets().open("replace_0.png"));
  Bitmap bit8=BitmapFactory.decodeStream(this.getContext().getAssets().open("replace_8.png")); 
  mReplaceMap2.put(0, bit0);
  mReplaceMap2.put(8, bit8);
  gsprite2.mReplaceMap=mReplaceMap2;
  
  
  mReplaceMap3.put(8, bit8);
  gsprite3.mReplaceMap=mReplaceMap3;
  
  mReplaceMap4.put(0, bit0);
  gsprite4.mReplaceMap=mReplaceMap4;
  }catch(Exception ex){
	  ex.printStackTrace();
  }
  }

  
	public HashMap<Integer, Bitmap> mReplaceMap2=new HashMap<Integer, Bitmap>(); 
	public HashMap<Integer, Bitmap> mReplaceMap3=new HashMap<Integer, Bitmap>(); 
	public HashMap<Integer, Bitmap> mReplaceMap4=new HashMap<Integer, Bitmap>(); 
  public void draw(Canvas mCanvas)
  {
	try{  
	  mCanvas.drawColor(0xff000000);
	    paint.setColor(0xffffffff);
	    mCanvas.drawText("����:"+spendtime+",֡��"+1000/(spendtime)+",������ʾ:"+xss, 30, 50, paint);
	 xss++;
	 
	 if(gsprite!=null){
		 gsprite.frameScale=1f;
	   gsprite.paint(mCanvas);
	 }
	 
	 if(gsprite2!=null){
		 gsprite2.frameScale=1f;
	   gsprite2.paint(mCanvas);
	 }
	 
	 if(gsprite3!=null){
		 gsprite3.frameScale=1f;
	   gsprite3.paint(mCanvas);
	 }
	 
	 if(gsprite4!=null){
		 gsprite4.frameScale=1f;
	   gsprite4.paint(mCanvas);
	 }
	 
	
	}catch(Exception ex){
		ex.printStackTrace();
	}
  }

  public void logic()
  {
  }

  @Override
  public boolean onTouchEvent(MotionEvent event)
  {
	    switch (event.getAction())
	    {
	      case MotionEvent.ACTION_DOWN:
	        break;
	      case MotionEvent.ACTION_MOVE:
	        dog_x = ( int ) event.getX();
	        dog_y = ( int ) event.getY();
	        break;
	      case MotionEvent.ACTION_UP:
	        break;
	    }
	    return true;
  }

  public boolean onKeyDown(int keyCode, KeyEvent event)
  {
	return true;

  }

  
//  @Override
//  protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec)
//  {
//    setMeasuredDimension(480, 640);
//  }
  long starttime=0;
  long endtime=0;
  long spendtime=1;
  public void run()
  {
    while (mIsRunning)
    {
      try
      {
    	  
        //Thread.sleep(80);
        starttime=System.currentTimeMillis();
        logic();
        Canvas mCanvas = mSurfaceHolder.lockCanvas();
        draw(mCanvas);
        mSurfaceHolder.unlockCanvasAndPost(mCanvas);
        endtime=System.currentTimeMillis();
        spendtime=endtime-starttime;
        if(spendtime>=33){
        	Thread.sleep(5);
        }else{
        	Thread.sleep(33-spendtime);
        }
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
    }
  }

  @Override
  public void surfaceChanged(SurfaceHolder holder, int format, int width, int height)
  {
  }

  @Override
  public void surfaceCreated(SurfaceHolder holder)
  {
    mIsRunning = true;
    mThread = new Thread(this);
    if (!mThread.isAlive())
    {
      mThread.start();
    }
  }

  @Override
  public void surfaceDestroyed(SurfaceHolder holder)
  {
    mIsRunning = false;
  }

  boolean mIsRunning = true;
  Thread mThread = null;
}
